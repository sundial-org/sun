# Editable paper sources

Compile `paper.tex` twice with pdfLaTeX. Compile `submission-notes.tex` separately
to produce the appended model-paper outline and revision notes. The original
CVPR style is included; its dependencies must be available in your TeX system.
No upload to Overleaf or submission service has been performed.

The paper uses normal Introduction, Related work, Method, Experiments, Results,
and Discussion sections. Figures are vector PDFs. Claim IDs are invisible in
the printed paper and connect the source to `CLAIMS.md` and `claim-checks.json`.
Editing a claim or numerical artifact invalidates its reviewed hash.

This is a compact typesetting bundle. Full responses, training records, offline
verification code and evidence live in the repository's
`experiments/continual_learning/paper/` directory. Large binary adapters remain
in the local experiment run archive; they are not included here.
